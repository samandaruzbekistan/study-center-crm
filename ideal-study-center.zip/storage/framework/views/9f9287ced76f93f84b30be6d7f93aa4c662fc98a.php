<table>
    <thead>
    <tr>
        <th>Student</th>
        <th>Teacher</th>
        <th>Group</th>
        <th>O'quv oyi</th>
        <th>Qarzdorlik</th>
        <!-- Add more columns as needed -->
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($payment->student->name); ?></td>
            <td><?php echo e($payment->teacher->name); ?></td>
            <td><?php echo e($payment->attach->subject_name); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($payment->month)->format('F Y')); ?></td>
            <td><?php echo e($payment->amount); ?></td>
            <!-- Add more columns as needed -->
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\OpenServer\domains\ideal-study-center\resources\views/exports/debt.blade.php ENDPATH**/ ?>