<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('sms'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <div class="col-12 col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">SMS xabarnoma xizmati</h5>
                        <div class="card-actions float-end" role="tablist"  >
                            <a class="btn btn-sm btn-light active" data-bs-toggle="list" href="#teachers" role="tab" aria-selected="true">
                                Ustozlarga
                            </a>
                            <a class="btn btn-sm btn-light" data-bs-toggle="list" href="#students" role="tab" aria-selected="true">
                                O'quvchilarga
                            </a>

                            <a class="btn btn-sm btn-light" data-bs-toggle="list" href="#parents" role="tab" aria-selected="true">
                                Ota onalarga
                            </a>

                            <a class="btn btn-sm btn-light" data-bs-toggle="list" href="#group" role="tab" aria-selected="true">
                                Guruh bo'yicha
                            </a>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade active show " id="teachers" role="tabpanel">
                            <div class="m-3 col-6">
                                <h6 class="card-title"><span class="text-danger">Ustozlarga</span> sms jo'natish</h6>
                                <form action="<?php echo e(route('admin.sms.teachers')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <textarea required name="message" class="form-control" rows="3" placeholder="Xabar matni"></textarea>
                                    <input type="submit" class="btn btn-success mt-3" value="Yuborish">
                                </form>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="students" role="tabpanel">
                            <div class="m-3 col-6">
                                <h6 class="card-title"><span class="text-danger">O'quvchilarga</span> sms jo'natish</h6>
                                <form>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="subject_id" value="0">
                                    <textarea required name="message" class="form-control" rows="3" placeholder="Xabar matni"></textarea>
                                    <input type="submit" class="btn btn-success mt-3" value="Yuborish">
                                </form>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="parents" role="tabpanel">
                            <div class="m-3 col-6">
                                <h6 class="card-title"><span class="text-danger">Ota-onalarga</span> sms jo'natish</h6>
                                <form>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="subject_id" value="0">
                                    <textarea required name="message" class="form-control" rows="3" placeholder="Xabar matni"></textarea>
                                    <input type="submit" class="btn btn-success mt-3" value="Yuborish">
                                </form>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="group" role="tabpanel">
                            <div class="m-3 col-6">
                                <h6 class="card-title"><span class="text-danger">Guruh</span> bo'yicha jo'natish</h6>
                                <form>
                                    <?php echo csrf_field(); ?>
                                    <select class="form-select mb-3" required name="subject_id" id="monthInput">
                                        <option selected disabled hidden value="">Guruhni tanlang</option>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <select class="form-select mb-3" required name="subject_id" id="monthInput">
                                        <option selected disabled hidden value="">Kimga yuborilsin</option>
                                        <option value="students">O'quvchiga</option>
                                        <option value="parents">Ota-onaga</option>
                                    </select>
                                    <textarea required name="message" class="form-control" rows="3" placeholder="Xabar matni"></textarea>
                                    <input type="submit" class="btn btn-success mt-3" value="Yuborish">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        <?php if(session('success') == 1): ?>
        const notyf = new Notyf();

        notyf.success({
            message: 'SMS xabar yuborildi',
            duration: 5000,
            dismissible : true,
            position: {
                x : 'center',
                y : 'top'
            },
        });
        <?php endif; ?>

        <?php if(session('error') == 1): ?>
        const notyf = new Notyf();

        notyf.error({
            message: 'Xatolik! Balansni tekshiring',
            duration: 5000,
            dismissible : true,
            position: {
                x : 'center',
                y : 'top'
            },
        });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\ideal-study-center\resources\views/admin/sms.blade.php ENDPATH**/ ?>