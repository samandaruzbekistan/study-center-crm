<?php $__env->startSection('teacher'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>

    <main class="content edit-forma" style="padding-bottom: 0; display: none">
        <div class="container-fluid p-0">
            <div class="col-md-8 col-xl-9">
                <div class="">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0"><span id="name" class="text-danger"></span> ning parolni yangilash</h5>
                        </div>
                        <div class="card-body h-100">
                            <form action="<?php echo e(route('admin.update.teacher')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="username" id="username">
                                <div class="mb-3">
                                    <label class="form-label">Yangi parol</label>
                                    <input required name="password1" type="password" class="form-control" placeholder="">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Yangi parolni takrorlang</label>
                                    <input required name="password2" type="password" class="form-control" placeholder="">
                                </div>
                                <div class=" text-end">
                                    <button type="button" class="btn btn-danger cancel1">Bekor qilish</button>
                                    <button type="submit" class="btn btn-success">Yangilash</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <main class="content forma" style="padding-bottom: 0; display: none">
        <div class="container-fluid p-0">
            <div class="col-md-8 col-xl-9">
                <div class="">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Yangi ustoz qo'shish</h5>
                        </div>
                        <div class="card-body h-100">
                            <form action="<?php echo e(route('admin.new.teacher')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label class="form-label">Ism familya <span class="text-danger">*</span></label>
                                    <input name="name" required type="text" class="form-control" placeholder="">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Fan <span class="text-danger">*</span></label>
                                    <input name="subject" required type="text" class="form-control" placeholder="">
                                </div>
                                <label class="form-label">Telefon <span class="text-danger">*</span></label>
                                <div class="input-group mb-3">
                                    <span class="input-group-text">+998</span>
                                    <input type="number" required name="phone" maxlength="9" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Rasm</label>
                                    <input class="form-control" type="file" name="photo" accept="image/*">
                                    <small class="text-danger">Rasm hajmi 2 mb dan oshmasligi kerak</small>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Login <span class="text-danger">*</span></label>
                                    <input name="username" required type="text" class="form-control" placeholder="">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Parol <span class="text-danger">*</span></label>
                                    <input name="password" required type="password" class="form-control" placeholder="">
                                </div>
                                <div class=" text-end">
                                    <button type="button" class="btn btn-danger cancel">Bekor qilish</button>
                                    <button type="submit" class="btn btn-success">Qo'shish</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <main class="content teachers">
        <div class="container-fluid p-0">
            <div class="col-12 col-xl-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5 class="card-title">Ustozlar ro'yhati</h5>
                        <button class="btn btn-primary add"><i class="align-middle" data-feather="user-plus"></i> Qo'shish</button>
                    </div>
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>Ism</th>
                            <th>Telefon</th>
                            <th>Fan</th>
                            <th>Login</th>
                            <th>Edit</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img src="<?php echo e(asset('img/avatars')); ?>/<?php echo e($item->photo); ?>" width="35" height="35" class="rounded-circle me-2" alt="Avatar"> <?php echo e($item->name); ?>

                                </td>
                                <td><?php echo e($item->phone); ?></td>
                                <td><?php echo e($item->subject); ?></td>
                                <td><?php echo e($item->username); ?></td>
                                <td id="<?php echo e($item->username); ?>" data="<?php echo e($item->name); ?>" class="edit-btn" style="cursor: pointer"><i class="align-middle" data-feather="edit-2"></i></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(".add").on("click", function() {
            $('.forma').show();
            $('.teachers').hide();
        });

        $(".cancel").on("click", function() {
            event.stopPropagation();
            $('.forma').hide();
            $('.teachers').show();
        });

        $(".cancel1").on("click", function() {
            event.stopPropagation();
            $('.edit-forma').hide();
            $('.teachers').show();
        });

        $(".edit-btn").on("click", function() {
            let username = $(this).attr('id');
            let name = $(this).attr('data');
            $('#username').val(username);
            $('#name').text(name);
            $('.edit-forma').show();
            $('.teachers').hide();
        });

        <?php if($errors->any()): ?>
            const notyf = new Notyf();

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                notyf.error({
                    message: '<?php echo e($error); ?>',
                    duration: 5000,
                    dismissible: true,
                    position: {
                    x: 'center',
                    y: 'top'
                },
            });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>

        <?php if(session('password_error') == 1): ?>
        const notyf = new Notyf();

        notyf.error({
            message: 'Parollar bir xil emas!',
            duration: 5000,
            dismissible : true,
            position: {
                x : 'center',
                y : 'top'
            },
        });
        <?php endif; ?>

        <?php if(session('success') == 1): ?>
        const notyf = new Notyf();

        notyf.success({
            message: 'Ustoz muvaffaqiyatli qo\'shildi!',
            duration: 5000,
            dismissible : true,
            position: {
                x : 'center',
                y : 'top'
            },
        });
        <?php endif; ?>

        <?php if(session('change') == 2): ?>
        const notyf = new Notyf();

        notyf.success({
            message: 'Parol muvaffaqiyatli o\'zgartirildi',
            duration: 5000,
            dismissible : true,
            position: {
                x : 'center',
                y : 'top'
            },
        });
        <?php endif; ?>

        <?php if(session('username_error') == 1): ?>
        const notyf = new Notyf();

        notyf.error({
            message: 'Xatolik! Bunday login mavjud',
            duration: 5000,
            dismissible : true,
            position: {
                x : 'center',
                y : 'top'
            },
        });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\ideal-study-center\resources\views\admin\teachers.blade.php ENDPATH**/ ?>