<?php $__env->startSection('subjects'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>

    <main class="content teachers">
        <div class="container-fluid p-0">
            <div class="col-12 col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-6">
                                <h5 class="card-title mb-0">Guruhlar ro'yhati</h5>
                            </div>
                        </div>
                    </div>
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>Nomi</th>
                            <th>Narxi</th>
                            <th>O'qituvchi</th>
                            <th>Darslar soni</th>
                        </tr>
                        </thead>
                        <tbody id="tbody">
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('admin.subject.students', ['subject_id' => $subject->id])); ?>"><?php echo e($subject->name); ?></a>
                                </td>
                                <td><b><?php echo e(number_format($subject->price, 0, '.', ' ')); ?></b> so'm</td>
                                <td><?php echo e($subject->teacher->name); ?></td>
                                <td><?php echo e($subject->lessons_count); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\ideal-study-center\resources\views/admin/subjects.blade.php ENDPATH**/ ?>